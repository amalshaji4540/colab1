# colab1 
print("hello world")
